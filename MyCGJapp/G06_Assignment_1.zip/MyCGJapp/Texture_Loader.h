void Texture2D_Loader(unsigned int *textureArray, const char *strFileName, int ID);
void TextureCubeMap_Loader(unsigned int *textureArray, const char **strFileName, int ID);